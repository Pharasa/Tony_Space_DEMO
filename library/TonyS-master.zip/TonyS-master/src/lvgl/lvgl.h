// dummy include lvgl.h
#ifndef LVGL_h
#define LVGL_h
#include "Module/Display/littlevglESP32/src/lvgl/lvgl.h"
#endif